<!doctype html>
<html lang="fr" class="no-js">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="css/reset.css">
<!-- Réinitialisation CSS -->
<link rel="stylesheet" href="css/style.css">
<!-- Style de la ressource -->
<script src="js/modernizr.js"></script>
<!-- Modernizr -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/user.css">
<link rel="stylesheet" href="assets/w3css/w3.css">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700,400italic,700italic" rel="stylesheet" type="text/css">
<link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
<title>FAQ | Location de voitures</title>
<!-- Navigation -->
<nav class="navbar navbar-custom" role="navigation" style="color: black">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                <i class="fa fa-bars"></i>
                </button>
            <a class="navbar-brand page-scroll" href="../index.php">
               VoitureEnLocation</a>
        </div>
        <!-- Collecte des liens de navigation, des formulaires et d'autres contenus pour basculer -->

        <?php
            if(isset($_SESSION['login_client'])){
        ?>
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php">Accueil</a>
                    </li>
                    <li>
                        <a href="#"><span class="glyphicon glyphicon-user"></span> Bienvenue <?php echo $_SESSION['login_client']; ?></a>
                    </li>
                    <li>
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user"></span> Panneau de contrôle <span class="caret"></span> </a>
                                <ul class="dropdown-menu">
                                    <li> <a href="entercar.php">Ajouter une voiture</a></li>
                                    <li> <a href="enterdriver.php">Ajouter un chauffeur</a></li>
                                    <li> <a href="clientview.php">Voir</a></li>

                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Déconnexion</a>
                    </li>
                </ul>
            </div>

            <?php
            }
            else if (isset($_SESSION['login_customer'])){
        ?>
                <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="index.php">Accueil</a>
                        </li>
                        <li>
                            <a href="#"><span class="glyphicon glyphicon-user"></span> Bienvenue <?php echo $_SESSION['login_customer']; ?></a>
                        </li>
                        <ul class="nav navbar-nav">
                            <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Garage <span class="caret"></span> </a>
                                <ul class="dropdown-menu">
                                    <li> <a href="prereturncar.php">Rendre maintenant</a></li>
                                    <li> <a href="mybookings.php">Mes réservations</a></li>
                                </ul>
                            </li>
                        </ul>
                        <li>
                            <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Déconnexion</a>
                        </li>
                    </ul>
                </div>

                <?php
        }
            else {
        ?>

                    <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                        <ul class="nav navbar-nav">
                            <li>
                                <a href="../index.php">Accueil</a>
                            </li>
                            <li>
                                <a href="../clientlogin.php">Employé</a>
                            </li>
                            <li>
                                <a href="../customerlogin.php">Client</a>
                            </li>
                            <li>
                                <a href="faq/index.html">FAQ</a>
                            </li>
                        </ul>
                    </div>
                    <?php   }
            ?>
                    <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>

<section class="cd-faq">
    <ul class="cd-faq-categories">
        <li><a class="selected" href="#basics">Principes de base</a></li>
        <li><a href="#membership">Adhésion</a></li>
        <li><a href="#chauffeur">Services de chauffeur</a></li>
    </ul>
    <!-- cd-faq-categories -->

    <div class="cd-faq-items">
        <ul id="basics" class="cd-faq-group">
            <li class="cd-faq-title">
                <h2>Principes de base</h2>
            </li>
            <li>
                <a class="cd-faq-trigger" href="#0">Comment puis-je payer ma location ?</a>
                <div class="cd-faq-content">
                    <p>VoitureEnLocation accepte volontiers les cartesmanitiques . Les chèques personnels sont également acceptés à condition que vous souscriviez une assurance collision et vol pour votre location.
                     À l'heure actuelle, nous tenons à vous informer que les chèques personnels ne sont pas acceptés sur place.</p>
                </div>
                <!-- cd-faq-content -->
            </li>

            <li>
                <a class="cd-faq-trigger" href="#0">Que faire si je trouve un meilleur tarif pour une location de voiture ?</a>
                <div class="cd-faq-content">
                    <p>L'un des nombreux avantages de Car Rentals est que nos tarifs de location et nos services sont garantis comme étant les meilleurs de l'industrie. Si vous trouvez un prix inférieur chez un concurrent et que le tarif concerne un véhicule comparable comprenant les mêmes conditions, les mêmes lieux et les mêmes frais de location de voiture, nous serons ravis de vous proposer un tarif inférieur. Veuillez remplir notre formulaire de meilleur tarif garanti si vous avez trouvé un meilleur tarif chez l'un de nos concurrents.</div>
                <!-- cd-faq-content -->
            </li>

            <li>
                <a class="cd-faq-trigger" href="#0">Ai-je besoin d'un permis de conduire pour louer une voiture ?</a>
                <div class="cd-faq-content">
                    <p>Un permis de conduire n'est pas nécessaire car un chauffeur est déjà fourni par l'employé.</p>
                </div>
                <!-- cd-faq-content -->
            </li>

            <li>
                <a class="cd-faq-trigger" href="#0">Y a-t-il des frais si je rends la voiture après la date limite ?</a>
                <div class="cd-faq-content">
                    <p>Oui, nous facturons 200 ₹ par jour après la date limite.</p>
                </div>
                <!-- cd-faq-content -->
            </li>
        </ul>
        

            <ul id="membership" class="cd-faq-group">
                <li class="cd-faq-title">
                    <h2>Adhésion</h2>
                </li>
                <li>
                    <a class="cd-faq-trigger" href="#0">Pourquoi devrais-je m'inscrire ?</a>
                    <div class="cd-faq-content">
                        <p>Lorsque vous vous inscrivez en tant que membre sur notre site, vous pourrez gagner du temps en remplissant les demandes. Une fois que vous vous êtes inscrit et connecté, chaque fois que vous nous envoyez une demande, nous préremplirons le formulaire de soumission avec vos informations personnelles afin que vous n'ayez pas à taper les mêmes choses encore et encore. Nous vous offrons également la possibilité de vous inscrire à notre newsletter par e-mail, qui vous tiendra au courant des dernières offres spéciales et incitations que nous proposons.</p>
                    </div>
                    <!-- cd-faq-content -->
                </li>

                <li>
                    <a class="cd-faq-trigger" href="#0">Comment devenir membre ?</a>
                    <div class="cd-faq-content">
                        <p>Il existe deux façons de s'inscrire. Vous pouvez soit aller directement sur notre formulaire d'inscription, soit simplement remplir une demande comme vous le feriez normalement. Après avoir envoyé cette demande, vous aurez l'occasion de vous inscrire. Si vous choisissez de le faire, lorsque vous accédez au formulaire d'inscription, les informations que vous avez fournies pour votre demande seront préremplies dans le formulaire d'inscription.</p>
                    </div>
                    <!-- cd-faq-content -->
                </li>
                <li>
                    <a class="cd-faq-trigger" href="#0">Comment me connecter ?</a>
                    <div class="cd-faq-content">
                        <p>Une fois que vous vous êtes inscrit, nous vous redirigerons vers l'écran de connexion. Lorsque vous êtes connecté, vous verrez une petite barre dans le coin supérieur droit de l'écran vous souhaitant la bienvenue sur notre site. Si vous avez déjà créé un compte mais que vous vous êtes déconnecté, vous pouvez soit cliquer sur le bouton "Connexion" de notre barre de menu, ce qui vous mènera à notre page de connexion, soit, si vous êtes sur notre page d'accueil, vous pouvez utiliser la zone de connexion qui s'y trouve.</p>
                    </div>
                    <!-- cd-faq-content -->
                </li>
                <li>
                    <a class="cd-faq-trigger" href="#0">Qu'en est-il de ma vie privée ?</a>
                    <div class="cd-faq-content">
                        <p>Votre vie privée est très importante pour nous. Tant que vous ne partagez pas votre nom d'utilisateur et votre mot de passe avec d'autres personnes, personne ne pourra voir ou modifier vos informations personnelles. Pour plus d'informations, veuillez lire notre politique de confidentialité.</p>
                    </div>
                    <!-- cd-faq-content -->
                </li>
                <li>
                    <a class="cd-faq-trigger" href="#0">Que se passe-t-il si je partage mon ordinateur ?</a>
                    <div class="cd-faq-content">
                        <p>Si vous partagez votre ordinateur avec d'autres personnes, vous devez vous déconnecter lorsque vous avez terminé votre session sur notre site web. De plus, lorsque vous vous connectez, assurez-vous que la case à cocher "Enregistrer mon mot de passe sur cet ordinateur" n'est pas cochée. En prenant ces mesures, vous vous assurerez que la prochaine personne utilisant l'ordinateur n'aura pas accès à votre compte.</p>
                    </div>
                    <!-- cd-faq-content -->
                </li>
                <li>
                    <a class="cd-faq-trigger" href="#0">Mes informations de carte de crédit sont-elles stockées dans mon compte ?</a>
                    <div class="cd-faq-content">
                        <p>Non. Nous ne stockons aucune information de carte de crédit dans votre compte.</p>
                    </div>
                    <!-- cd-faq-content -->
                </li>
            </ul>

            <ul id="chauffeur" class="cd-faq-group">
                <li class="cd-faq-title">
                    <h2>Service de chauffeur</h2>
                </li>
                <li>
                    <a class="cd-faq-trigger" href="#0">Proposez-vous des services d'accueil et d'accompagnement ?</a>
                    <div class="cd-faq-content">
                        <p>Vous serez accueilli dans les aéroports et autres lieux publics avec une pancarte. Nous pouvons également vous retrouver à votre hôtel et dans d'autres endroits.</p>
                    </div>
                    <!-- cd-faq-content -->
                </li>

                <li>
                    <a class="cd-faq-trigger" href="#0">Comment puis-je payer mes services de chauffeur ?</a>
                    <div class="cd-faq-content">
                        <p>Car Rentals accepte avec plaisir les cartes Mastercard, Visa et les chèques. Nous acceptons également PayTm.</p>
                    </div>
                    <!-- cd-faq-content -->
                </li>

                <li>
                    <a class="cd-faq-trigger" href="#0">Y a-t-il des frais si je change mes services de chauffeur ?</a>
                    <div class="cd-faq-content">
                        <p>Il n'y a aucun frais pour modifier les réservations de services de chauffeur.</p>
                    </div>
                    <!-- cd-faq-content -->
                </li>
            </ul>
        </div>
        <!-- cd-faq-items -->
        <a href="#0" class="cd-close-panel">Fermer</a>
    </section>
    <!-- cd-faq -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/jquery.mobile.custom.min.js"></script>
    <script src="js/main.js"></script>
    <!-- Resource jQuery -->
</body>

</html>
