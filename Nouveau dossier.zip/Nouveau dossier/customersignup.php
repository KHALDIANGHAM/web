<html>
<head>
    <title>Inscription client |   VoitureEnLocation</title>
    <link rel="shortcut icon" type="image/png" href="assets/img/P.png.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/w3css/w3.css">
    <script type="text/javascript" src="assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="assets/css/clientlogin.css">
<body>
     <!-- Navigation -->
     <nav class="navbar navbar-custom navbar-fixed-top" role="navigation" style="color: black">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                    </button>
                <a class="navbar-brand page-scroll" href="index.php">
                   VoitureEnLocation </a>
            </div>
            <!-- Collecter les liens de navigation, les formulaires et autres contenus pour le basculement -->
            <?php
                if(isset($_SESSION['login_client'])){
            ?>
                <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="index.php">Accueil</a>
                        </li>
                        <li>
                            <a href="#"><span class="glyphicon glyphicon-user"></span> Bienvenue <?php echo $_SESSION['login_client']; ?></a>
                        </li>
                        <li>
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user"></span> Panneau de contrôle <span class="caret"></span> </a>
                                    <ul class="dropdown-menu">
                                        <li> <a href="entercar.php">Ajouter une voiture</a></li>
                                        <li> <a href="enterdriver.php">Ajouter un conducteur</a></li>
                                        <li> <a href="clientview.php">Voir</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Se déconnecter</a>
                        </li>
                    </ul>
                </div>
                <?php
                }
                else if (isset($_SESSION['login_customer'])){
            ?>
                    <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                        <ul class="nav navbar-nav">
                            <li>
                                <a href="index.php">Accueil</a>
                            </li>
                            <li>
                                <a href="#"><span class="glyphicon glyphicon-user"></span> Bienvenue <?php echo $_SESSION['login_customer']; ?></a>
                            </li>
                            <li>
                                <a href="#">Historique</a>
                            </li>
                            <li>
                                <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Se déconnecter</a>
                            </li>
                        </ul>
                    </div>
                    <?php
        }
            else {
        ?>

                    <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
                        <ul class="nav navbar-nav">
                            <li>
                                <a href="index.php">Accueil</a>
                            </li>
                            <li>
                                <a href="clientlogin.php">Employé</a>
                            </li>
                            <li>
                                <a href="customerlogin.php">Reservation</a>
                            </li>
                            <li>
                                <a href="#">FAQ</a>
                            </li>
                        </ul>
                    </div>
                    <?php   }
            ?>
                    <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>
<div class="container">
    <div class="jumbotron">
        <h1 class="text-center">  VoitureEnLocation - Inscription</h1>
        <br>
        <p class="text-center">Commencez en créant un compte client</p>
    </div>
</div>

<div class="container" style="margin-top: -1%; margin-bottom: 2%;">
    <div class="col-md-5 col-md-offset-4">
        <div class="panel panel-primary">
            <div class="panel-heading">Créer un compte</div>
            <div class="panel-body">

                <form role="form" action="customer_registered_success.php" method="POST">

                    <div class="row">
                        <div class="form-group col-xs-12">
                            <label for="customer_name"><span class="text-danger" style="margin-right: 5px;">*</span> Nom complet : </label>
                            <div class="input-group">
                                <input class="form-control" id="customer_name" type="text" name="customer_name" placeholder="Votre nom complet" required="" autofocus="">
                                <span class="input-group-btn">
              <label class="btn btn-primary"><span class="glyphicon glyphicon-user" aria-hidden="true"></label>
          </span>
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-xs-12">
                            <label for="customer_username"><span class="text-danger" style="margin-right: 5px;">*</span> Nom d'utilisateur : </label>
                            <div class="input-group">
                                <input class="form-control" id="customer_username" type="text" name="customer_username" placeholder="Votre nom d'utilisateur" required="">
                                <span class="input-group-btn">
              <label class="btn btn-primary"><span class="glyphicon glyphicon-user" aria-hidden="true"></label>
          </span>
                                </span>
                            </div>
                        </div>
                    </div><div class="row">
    <div class="form-group col-xs-12">
        <label for="customer_email"><span class="text-danger" style="margin-right: 5px;">*</span> Email :</label>
        <div class="input-group">
            <input class="form-control" id="customer_email" type="email" name="customer_email" placeholder="Email" required="">
            <span class="input-group-btn">
                <label class="btn btn-primary"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span></label>
            </span>
        </div>
    </div>
</div>
<div class="row">
    <div class="form-group col-xs-12">
        <label for="customer_phone"><span class="text-danger" style="margin-right: 5px;">*</span> Téléphone :</label>
        <div class="input-group">
            <input class="form-control" id="customer_phone" type="text" name="customer_phone" placeholder="Téléphone" required="">
            <span class="input-group-btn">
                <label class="btn btn-primary"><span class="glyphicon glyphicon-contact" aria-hidden="true"></span></label>
            </span>
        </div>
    </div>
</div>
<div class="row">
    <div class="form-group col-xs-12">
        <label for="customer_address"><span class="text-danger" style="margin-right: 5px;">*</span> Adresse :</label>
        <div class="input-group">
            <input class="form-control" id="customer_address" type="text" name="customer_address" placeholder="Adresse" required="">
            <span class="input-group-btn">
                <label class="btn btn-primary"><span class="glyphicon glyphicon-home" aria-hidden="true"></span></label>
            </span>
        </div>
    </div>
</div>
<div class="row">
    <div class="form-group col-xs-12">
        <label for="customer_password"><span class="text-danger" style="margin-right: 5px;">*</span> Mot de passe :</label>
        <div class="input-group">
            <input class="form-control" id="customer_password" type="password" name="customer_password" placeholder="Mot de passe" required="">
            <span class="input-group-btn">
                <label class="btn btn-primary"><span class="glyphicon glyphicon-lock" aria-hidden="true"></span></label>
            </span>
        </div>
    </div>
</div>
<div class="row">
    <div class="form-group col-xs-4">
        <button class="btn btn-primary" type="submit">Soumettre</button>
    </div>
</div>
<label style="margin-left: 5px;">ou</label> <br>
<label style="margin-left: 5px;"><a href="customerlogin.php">Vous avez déjà un compte ? Connectez-vous.</a></label>

</form>
</div>
</div>
</div>
</div>
</body>
<footer class="site-footer">
    <div class="container">
        <hr>
        <div class="row">
            <div class="col-sm-6">
                <h5>© <?php echo date("Y"); ?> Location de voitures</h5>
            </div>
        </div>
    </div>
</footer>
</html>

