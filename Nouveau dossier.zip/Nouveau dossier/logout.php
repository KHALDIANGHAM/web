<?php
session_start();
if(session_destroy()) // Destruction de toutes les sessions
{
    header("Location: index.php"); // Redirection vers la page d'accueil
}
?>
