<?php
session_start(); // Démarrage de la session
$error=''; // Variable pour stocker le message d'erreur

if (isset($_POST['submit'])) {
    if (empty($_POST['client_username']) || empty($_POST['client_password'])) {
        $error = "Nom d'utilisateur ou mot de passe invalide";
    }
    else {
        // Définition de $username et $password
        $client_username = $_POST['client_username'];
        $client_password = $_POST['client_password'];

        // Établissement de la connexion avec le serveur en passant le nom du serveur, l'identifiant de l'utilisateur et le mot de passe en tant que paramètres
        require 'connection.php';
        $conn = Connect();

        // Requête SQL pour récupérer les informations des utilisateurs enregistrés et trouver une correspondance d'utilisateur.
        $query = "SELECT client_username, client_password FROM clients WHERE client_username=? AND client_password=? LIMIT 1";

        // Pour protéger contre les injections MySQL à des fins de sécurité
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $client_username, $client_password);
        $stmt->execute();
        $stmt->bind_result($client_username, $client_password);
        $stmt->store_result();

        if ($stmt->fetch()) { // Récupération du contenu de la ligne
            $_SESSION['login_client'] = $client_username; // Initialisation de la session
            header("location: index.php"); // Redirection vers une autre page
        } else {
            $error = "Nom d'utilisateur ou mot de passe invalide";
        }
        mysqli_close($conn); // Fermeture de la connexion
    }
}
?>
