<?php
// La fonction mysqli_connect() ouvre une nouvelle connexion au serveur MySQL.
require 'connection.php';
$conn = Connect();

session_start(); // Démarrage de la session

// Stockage de la session
$user_check = $_SESSION['login_client'];

// Requête SQL pour récupérer toutes les informations de l'utilisateur
$query = "SELECT client_username FROM clients WHERE client_username = '$user_check'";
$ses_sql = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($ses_sql);
$login_session = $row['client_username'];
?>
