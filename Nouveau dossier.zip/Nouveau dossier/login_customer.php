<?php
session_start(); // Démarrage de la session
$error = ''; // Variable pour stocker le message d'erreur

if (isset($_POST['submit'])) {
    if (empty($_POST['customer_username']) || empty($_POST['customer_password'])) {
        $error = "Nom d'utilisateur ou mot de passe invalide";
    } else {
        // Définition des variables $customer_username et $customer_password
        $customer_username = $_POST['customer_username'];
        $customer_password = $_POST['customer_password'];

        // Établissement de la connexion avec le serveur en passant le nom du serveur, l'identifiant de l'utilisateur et le mot de passe en tant que paramètres
        require 'connection.php';
        $conn = Connect();

        // Requête SQL pour récupérer les informations des utilisateurs enregistrés et trouver une correspondance d'utilisateur
        $query = "SELECT customer_username, customer_password FROM customers WHERE customer_username=? AND customer_password=? LIMIT 1";

        // Protection contre les injections SQL à des fins de sécurité
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $customer_username, $customer_password);
        $stmt->execute();
        $stmt->bind_result($customer_username, $customer_password);
        $stmt->store_result();

        if ($stmt->fetch()) { // Récupération du contenu de la ligne
            $_SESSION['login_customer'] = $customer_username; // Initialisation de la session
            header("location: index.php"); // Redirection vers une autre page
        } else {
            $error = "Nom d'utilisateur ou mot de passe invalide";
        }
        mysqli_close($conn); // Fermeture de la connexion
    }
}
?>
